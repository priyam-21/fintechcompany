export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  features: string[];
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  image: string;
  rating: number;
}

export interface SuccessStory {
  id: string;
  title: string;
  description: string;
  results: {
    label: string;
    value: string;
  }[];
  image: string;
}