import { Service, Testimonial, SuccessStory } from './types';
import { Briefcase, Shield, LineChart, GraduationCap, TrendingUp, PieChart } from 'lucide-react';

export const services: Service[] = [
  {
    id: 'insurance',
    title: 'Insurance Services',
    description: 'Comprehensive insurance solutions tailored to protect your future.',
    icon: 'Shield',
    features: ['Life Insurance', 'Health Insurance', 'Vehicle Insurance', 'Investment-Linked Plans']
  },
  {
    id: 'mutual-funds',
    title: 'Mutual Funds',
    description: 'Strategic investment solutions for long-term wealth creation.',
    icon: 'LineChart',
    features: ['SIP Plans', 'Equity Funds', 'Debt Funds', 'Hybrid Funds']
  },
  {
    id: 'wealth-management',
    title: 'Wealth Management',
    description: 'Personalized strategies for optimal financial growth.',
    icon: 'Briefcase',
    features: ['Financial Planning', 'Asset Allocation', 'Risk Management', 'Estate Planning']
  },
  {
    id: 'financial-education',
    title: 'Financial Education',
    description: 'Empowering clients with financial knowledge and insights.',
    icon: 'GraduationCap',
    features: ['Webinars', 'Workshops', 'Online Courses', 'Personal Coaching']
  },
  {
    id: 'stock-advisory',
    title: 'Stock Market Advisory',
    description: 'Expert guidance for stock market investments.',
    icon: 'TrendingUp',
    features: ['Portfolio Analysis', 'Stock Recommendations', 'Market Research', 'Risk Assessment']
  },
  {
    id: 'portfolio-management',
    title: 'Portfolio Management',
    description: 'Professional management of your investment portfolio.',
    icon: 'PieChart',
    features: ['Portfolio Optimization', 'Regular Monitoring', 'Performance Reports', 'Rebalancing']
  }
];

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    role: 'Business Owner',
    content: 'The wealth management services have transformed my financial future. The personalized approach and expert guidance helped me achieve my investment goals.',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400',
    rating: 5
  },
  {
    id: '2',
    name: 'Michael Chen',
    role: 'Tech Executive',
    content: 'Outstanding portfolio management services. My investments have shown consistent growth thanks to their strategic approach and market insights.',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400',
    rating: 5
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    role: 'Doctor',
    content: "The insurance planning services provided were exceptional. They helped me secure my family's future with the right coverage.",
    image: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=400',
    rating: 5
  }
];

export const successStories: SuccessStory[] = [
  {
    id: '1',
    title: 'Retirement Portfolio Optimization',
    description: 'Helped a client achieve their retirement goals through strategic asset allocation and risk management.',
    results: [
      { label: 'Portfolio Growth', value: '127%' },
      { label: 'Risk Reduction', value: '35%' },
      { label: 'Annual Returns', value: '18.5%' }
    ],
    image: 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=800'
  },
  {
    id: '2',
    title: 'Business Succession Planning',
    description: 'Developed a comprehensive succession plan for a family-owned business ensuring smooth transition.',
    results: [
      { label: 'Tax Savings', value: '42%' },
      { label: 'Business Value', value: '₹150M' },
      { label: 'Transition Time', value: '12 months' }
    ],
    image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800'
  }
];